exports.handler = async (event, context) => {
  try {
    // The event contains an array of records
    const records = event.Records;

    for (const record of records) {
      // Get the SNS message
      const snsMessage = record.Sns;

      // Extract relevant information
      const messageId = snsMessage.MessageId;
      const messageBody = snsMessage.Message;
      const timestamp = snsMessage.Timestamp;
      const subject = snsMessage.Subject || 'No Subject';

      console.log(`Processing SNS message: ${messageId}`);
      console.log(`Subject: ${subject}`);
      console.log(`Timestamp: ${timestamp}`);
      console.log(`Message: ${messageBody}`);

      // Parse the message if it's JSON
      try {
        const parsedMessage = JSON.parse(messageBody);
        console.log('Parsed message:', parsedMessage);

        // Add your business logic here to process the message
        // For example:
        if (parsedMessage.action === 'create') {
          await createResource(parsedMessage.data);
        } else if (parsedMessage.action === 'update') {
          await updateResource(parsedMessage.data);
        } else if (parsedMessage.action === 'delete') {
          await deleteResource(parsedMessage.id);
        }
      } catch (parseError) {
        // Handle case where message isn't JSON
        console.log('Message is not in JSON format, processing as plain text');
        // Process plain text message
        await processTextMessage(messageBody);
      }
    }

    return {
      statusCode: 200,
      body: JSON.stringify({ message: 'Successfully processed SNS messages' }),
    };
  } catch (error) {
    console.error('Error processing SNS message:', error);
    throw error;
  }
};

// Example helper functions (implement based on your needs)
async function createResource(data) {
  console.log(`Creating resource with data:`, data);
  // Implementation code here
}

async function updateResource(data) {
  console.log(`Updating resource with data:`, data);
  // Implementation code here
}

async function deleteResource(id) {
  console.log(`Deleting resource with ID: ${id}`);
  // Implementation code here
}

async function processTextMessage(message) {
  console.log(`Processing text message: ${message}`);
  // Implementation code here
}
